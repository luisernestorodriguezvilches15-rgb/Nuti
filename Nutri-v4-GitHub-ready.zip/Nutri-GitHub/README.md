# Nutri v4 — Android

Proyecto Android Kotlin + Jetpack Compose. Incluye diario local de comidas, perfil nutricional, catálogo inicial y lector de códigos de barras con CameraX/ML Kit y consulta a Open Food Facts.

## Generar APK con GitHub Actions

1. Sube el contenido completo de este proyecto a la raíz del repositorio GitHub (deben quedar `app/`, `gradle/`, `build.gradle.kts` y `settings.gradle.kts` en la raíz).
2. Abre la pestaña **Actions** y selecciona **Build Nutri APK**.
3. Cuando termine correctamente, abre la ejecución y descarga el artefacto **Nutri-debug-apk**.

El APK debug no está firmado para distribución en Play Store.

## Estado y limitaciones
- El proyecto requiere compilación real y pruebas en dispositivo.
- El análisis de fotografías con IA no está implementado. La función Edge incluida devuelve `501 not_configured`.
- No hay sincronización Supabase configurada en la app.
- Los datos de Open Food Facts pueden estar incompletos; revisa las etiquetas de los productos.
