package com.example.nutri

import android.content.Context
import android.Manifest
import android.content.pm.PackageManager
import android.view.ViewGroup
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.common.InputImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private const val PREFS = "nutri_local_data"
private const val MEALS_KEY = "meals"
private const val WEIGHTS_KEY = "weights"
private const val TARGET_KEY = "calorie_target"
private const val PROFILE_KEY = "profile"

data class Meal(
    val id: Long = System.currentTimeMillis(),
    val name: String,
    val calories: Int,
    val protein: Int,
    val carbs: Int,
    val fat: Int,
    val timestamp: Long = System.currentTimeMillis()
)
data class WeightEntry(val id: Long = System.currentTimeMillis(), val kg: Double, val timestamp: Long = System.currentTimeMillis())
data class UserProfile(
    val name: String = "",
    val age: Int = 30,
    val heightCm: Double = 170.0,
    val weightKg: Double = 70.0,
    val sex: String = "Mujer",
    val activity: String = "Moderada",
    val goal: String = "Mantener"
)
data class Food(
    val name: String,
    val calories: Int,
    val protein: Double,
    val carbs: Double,
    val fat: Double,
    val category: String
)

private val foodCatalog = listOf(
    Food("Pechuga de pollo cocida", 165, 31.0, 0.0, 3.6, "Proteínas"),
    Food("Huevo entero", 143, 12.6, 0.7, 9.5, "Proteínas"),
    Food("Atún en agua escurrido", 116, 25.5, 0.0, 0.8, "Proteínas"),
    Food("Salmón", 208, 20.4, 0.0, 13.4, "Proteínas"),
    Food("Arroz blanco cocido", 130, 2.7, 28.2, 0.3, "Cereales"),
    Food("Avena seca", 389, 16.9, 66.3, 6.9, "Cereales"),
    Food("Pan integral", 247, 13.0, 41.0, 4.2, "Cereales"),
    Food("Papa hervida", 87, 1.9, 20.1, 0.1, "Vegetales"),
    Food("Plátano", 89, 1.1, 22.8, 0.3, "Frutas"),
    Food("Manzana", 52, 0.3, 13.8, 0.2, "Frutas"),
    Food("Aguacate", 160, 2.0, 8.5, 14.7, "Grasas"),
    Food("Almendras", 579, 21.2, 21.6, 49.9, "Grasas"),
    Food("Leche entera", 61, 3.2, 4.8, 3.3, "Lácteos"),
    Food("Yogur natural", 61, 3.5, 4.7, 3.3, "Lácteos"),
    Food("Brócoli", 35, 2.4, 7.2, 0.4, "Vegetales"),
    Food("Frijoles cocidos", 127, 8.7, 22.8, 0.5, "Legumbres")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { NutriApp(applicationContext) }
    }
}

private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

private fun loadMeals(context: Context): List<Meal> = runCatching {
    val a = JSONArray(prefs(context).getString(MEALS_KEY, "[]"))
    (0 until a.length()).map { i ->
        val o = a.getJSONObject(i)
        Meal(o.optLong("id"), o.optString("name"), o.optInt("calories"), o.optInt("protein"), o.optInt("carbs"), o.optInt("fat"), o.optLong("timestamp"))
    }
}.getOrDefault(emptyList())

private fun saveMeals(context: Context, meals: List<Meal>) {
    val a = JSONArray()
    meals.forEach { m -> a.put(JSONObject().put("id", m.id).put("name", m.name).put("calories", m.calories).put("protein", m.protein).put("carbs", m.carbs).put("fat", m.fat).put("timestamp", m.timestamp)) }
    prefs(context).edit().putString(MEALS_KEY, a.toString()).apply()
}

private fun loadWeights(context: Context): List<WeightEntry> = runCatching {
    val a = JSONArray(prefs(context).getString(WEIGHTS_KEY, "[]"))
    (0 until a.length()).map { i -> val o = a.getJSONObject(i); WeightEntry(o.optLong("id"), o.optDouble("kg"), o.optLong("timestamp")) }
}.getOrDefault(emptyList())

private fun saveWeights(context: Context, entries: List<WeightEntry>) {
    val a = JSONArray()
    entries.forEach { w -> a.put(JSONObject().put("id", w.id).put("kg", w.kg).put("timestamp", w.timestamp)) }
    prefs(context).edit().putString(WEIGHTS_KEY, a.toString()).apply()
}

private fun loadProfile(context: Context): UserProfile = runCatching {
    val o = JSONObject(prefs(context).getString(PROFILE_KEY, "{}"))
    UserProfile(
        name = o.optString("name", ""),
        age = o.optInt("age", 30),
        heightCm = o.optDouble("heightCm", 170.0),
        weightKg = o.optDouble("weightKg", 70.0),
        sex = o.optString("sex", "Mujer"),
        activity = o.optString("activity", "Moderada"),
        goal = o.optString("goal", "Mantener")
    )
}.getOrDefault(UserProfile())

private fun saveProfile(context: Context, p: UserProfile) {
    val o = JSONObject().put("name", p.name).put("age", p.age).put("heightCm", p.heightCm)
        .put("weightKg", p.weightKg).put("sex", p.sex).put("activity", p.activity).put("goal", p.goal)
    prefs(context).edit().putString(PROFILE_KEY, o.toString()).apply()
}

private fun estimatedCalories(p: UserProfile): Int {
    val base = 10 * p.weightKg + 6.25 * p.heightCm - 5 * p.age + if (p.sex == "Hombre") 5 else -161
    val factor = when (p.activity) {
        "Ligera" -> 1.375
        "Moderada" -> 1.55
        "Alta" -> 1.725
        "Muy alta" -> 1.9
        else -> 1.2
    }
    val maintenance = base * factor
    val adjusted = when (p.goal) {
        "Perder peso" -> maintenance - 300
        "Ganar peso" -> maintenance + 250
        else -> maintenance
    }
    return adjusted.toInt().coerceIn(1000, 5000)
}

private fun sameDay(a: Long, b: Long): Boolean =
    SimpleDateFormat("yyyyMMdd", Locale.getDefault()).format(Date(a)) ==
        SimpleDateFormat("yyyyMMdd", Locale.getDefault()).format(Date(b))
private fun dateLabel(time: Long): String = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(time))

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NutriApp(context: Context) {
    var selected by remember { mutableStateOf("Inicio") }
    var meals by remember { mutableStateOf(loadMeals(context)) }
    var weights by remember { mutableStateOf(loadWeights(context)) }
    var profile by remember { mutableStateOf(loadProfile(context)) }
    var calorieTarget by remember { mutableIntStateOf(prefs(context).getInt(TARGET_KEY, 2000)) }
    var showAddMeal by remember { mutableStateOf(false) }
    var showAddWeight by remember { mutableStateOf(false) }
    var showTarget by remember { mutableStateOf(false) }
    var selectedFood by remember { mutableStateOf<Food?>(null) }
    var scannedFood by remember { mutableStateOf<Food?>(null) }

    val todayMeals = meals.filter { sameDay(it.timestamp, System.currentTimeMillis()) }.sortedByDescending { it.timestamp }
    val calories = todayMeals.sumOf { it.calories }
    val protein = todayMeals.sumOf { it.protein }
    val carbs = todayMeals.sumOf { it.carbs }
    val fat = todayMeals.sumOf { it.fat }

    MaterialTheme(colorScheme = lightColorScheme(primary = Color(0xFF197B55), secondary = Color(0xFF78A98B), background = Color(0xFFF6F8F5))) {
        Scaffold(
            topBar = { TopAppBar(title = { Text("Nutri", fontWeight = FontWeight.Bold) }, actions = { Text("Hábitos saludables", modifier = Modifier.padding(end = 12.dp), fontSize = 11.sp) }) },
            bottomBar = {
                NavigationBar {
                    NavigationBarItem(selected == "Inicio", { selected = "Inicio" }, icon = { Icon(Icons.Default.Home, null) }, label = { Text("Inicio") })
                    NavigationBarItem(selected == "Diario", { selected = "Diario" }, icon = { Icon(Icons.Default.Restaurant, null) }, label = { Text("Diario") })
                    NavigationBarItem(selected == "Alimentos", { selected = "Alimentos" }, icon = { Icon(Icons.Default.Search, null) }, label = { Text("Alimentos") })
                    NavigationBarItem(selected == "Progreso", { selected = "Progreso" }, icon = { Icon(Icons.Default.ShowChart, null) }, label = { Text("Progreso") })
                    NavigationBarItem(selected == "Perfil", { selected = "Perfil" }, icon = { Icon(Icons.Default.Person, null) }, label = { Text("Perfil") })
                }
            },
            floatingActionButton = {
                if (selected == "Inicio" || selected == "Diario") FloatingActionButton(onClick = { showAddMeal = true }) { Icon(Icons.Default.Add, contentDescription = "Añadir comida manual") }
                if (selected == "Progreso") FloatingActionButton(onClick = { showAddWeight = true }) { Icon(Icons.Default.Add, contentDescription = "Añadir peso") }
            }
        ) { padding ->
            when (selected) {
                "Inicio" -> HomeScreen(calories, calorieTarget, protein, carbs, fat, todayMeals, profile.name, Modifier.padding(padding))
                "Diario" -> DiaryScreen(meals.sortedByDescending { it.timestamp }, onDelete = { id -> meals = meals.filterNot { it.id == id }; saveMeals(context, meals) }, modifier = Modifier.padding(padding))
                "Alimentos" -> FoodCatalogScreen(Modifier.padding(padding), onAddFood = { selectedFood = it }, onScan = { selected = "Escáner" })
                "Escáner" -> BarcodeScannerScreen(
                    modifier = Modifier.padding(padding),
                    onFoodFound = { food -> selectedFood = food; selected = "Alimentos" }
                )
                "Progreso" -> ProgressScreen(calories, weights.sortedByDescending { it.timestamp }, Modifier.padding(padding))
                else -> ProfileScreen(profile, onSave = { p ->
                    profile = p
                    saveProfile(context, p)
                    val target = estimatedCalories(p)
                    calorieTarget = target
                    prefs(context).edit().putInt(TARGET_KEY, target).apply()
                }, modifier = Modifier.padding(padding))
            }
        }
    }

    if (showAddMeal) AddMealDialog(onDismiss = { showAddMeal = false }, onAdd = { meal -> meals = listOf(meal) + meals; saveMeals(context, meals); showAddMeal = false })
    if (showAddWeight) AddWeightDialog(onDismiss = { showAddWeight = false }, onAdd = { entry -> weights = listOf(entry) + weights; saveWeights(context, weights); showAddWeight = false })
    if (showTarget) TargetDialog(current = calorieTarget, onDismiss = { showTarget = false }, onSave = { value -> calorieTarget = value; prefs(context).edit().putInt(TARGET_KEY, value).apply(); showTarget = false })
    selectedFood?.let { food ->
        FoodAmountDialog(food, onDismiss = { selectedFood = null }, onAdd = { grams ->
            val ratio = grams / 100.0
            val meal = Meal(
                name = "$grams g de ${food.name}",
                calories = (food.calories * ratio).toInt(),
                protein = (food.protein * ratio).toInt(),
                carbs = (food.carbs * ratio).toInt(),
                fat = (food.fat * ratio).toInt()
            )
            meals = listOf(meal) + meals
            saveMeals(context, meals)
            selectedFood = null
            selected = "Diario"
        })
    }
}

@Composable
fun HomeScreen(calories: Int, target: Int, protein: Int, carbs: Int, fat: Int, meals: List<Meal>, userName: String, modifier: Modifier = Modifier) {
    LazyColumn(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item { Text(if (userName.isBlank()) "¡Hola! 👋" else "¡Hola, $userName! 👋", fontSize = 27.sp, fontWeight = FontWeight.Bold); Text("Tu resumen nutricional de hoy") }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Calorías consumidas"); Text("$calories kcal", fontSize = 34.sp, fontWeight = FontWeight.Bold)
                    Text("Objetivo diario: $target kcal")
                    LinearProgressIndicator(progress = { (calories / target.toFloat()).coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth())
                    Text(if (calories <= target) "Te quedan ${target - calories} kcal de tu objetivo" else "Has superado tu objetivo por ${calories - target} kcal", fontSize = 12.sp)
                }
            }
        }
        item { Text("Macronutrientes", fontSize = 19.sp, fontWeight = FontWeight.Bold); Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { MacroCard("Proteína", "${protein} g", Modifier.weight(1f)); MacroCard("Carbohidratos", "${carbs} g", Modifier.weight(1f)); MacroCard("Grasas", "${fat} g", Modifier.weight(1f)) } }
        item { Text("Comidas de hoy", fontSize = 19.sp, fontWeight = FontWeight.Bold) }
        if (meals.isEmpty()) item { Text("Todavía no has registrado comidas. Abre Alimentos o pulsa + para comenzar.") }
        items(meals, key = { it.id }) { MealRow(it) }
        item { Text("Importante", fontWeight = FontWeight.Bold); Text("Las metas son estimaciones orientativas. No sustituyen una evaluación nutricional individual.") }
    }
}

@Composable
fun MacroCard(title: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier) { Column(Modifier.padding(12.dp)) { Text(title, fontSize = 12.sp); Text(value, fontWeight = FontWeight.Bold, fontSize = 17.sp) } }
}

@Composable
fun MealRow(meal: Meal, onDelete: (() -> Unit)? = null) {
    Card {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(meal.name, fontWeight = FontWeight.SemiBold)
                Text("P ${meal.protein}g · C ${meal.carbs}g · G ${meal.fat}g", fontSize = 12.sp)
                Text(dateLabel(meal.timestamp), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Text("${meal.calories} kcal", fontWeight = FontWeight.Bold)
            if (onDelete != null) IconButton(onClick = onDelete) { Icon(Icons.Default.Delete, contentDescription = "Eliminar comida") }
        }
    }
}

@Composable
fun DiaryScreen(meals: List<Meal>, onDelete: (Long) -> Unit, modifier: Modifier = Modifier) {
    LazyColumn(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("Diario de comidas", fontSize = 25.sp, fontWeight = FontWeight.Bold); Text("Tus registros guardados en este dispositivo") }
        if (meals.isEmpty()) item { Text("Todavía no tienes comidas registradas.") }
        items(meals, key = { it.id }) { meal -> MealRow(meal) { onDelete(meal.id) } }
    }
}

@Composable
fun FoodCatalogScreen(modifier: Modifier = Modifier, onAddFood: (Food) -> Unit, onScan: () -> Unit) {
    var query by remember { mutableStateOf("") }
    val filtered = foodCatalog.filter { it.name.contains(query, ignoreCase = true) || it.category.contains(query, ignoreCase = true) }
    LazyColumn(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Text("Catálogo de alimentos", fontSize = 25.sp, fontWeight = FontWeight.Bold)
            Text("Valores aproximados por cada 100 gramos.")
            OutlinedButton(onClick = onScan, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.QrCodeScanner, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Escanear código de barras")
            }
            OutlinedTextField(query, { query = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Buscar alimento") }, leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true)
        }
        items(filtered, key = { it.name }) { food ->
            Card {
                Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(food.name, fontWeight = FontWeight.SemiBold)
                            Text(food.category, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Text("${food.calories} kcal", fontWeight = FontWeight.Bold)
                    }
                    Text("Proteína ${food.protein} g · Carbohidratos ${food.carbs} g · Grasas ${food.fat} g", fontSize = 12.sp)
                    OutlinedButton(onClick = { onAddFood(food) }, modifier = Modifier.align(Alignment.End)) { Text("Añadir al diario") }
                }
            }
        }
        if (filtered.isEmpty()) item { Text("No encontramos ese alimento en el catálogo inicial.") }
    }
}

private suspend fun lookupOpenFoodFacts(barcode: String): Food? = withContext(Dispatchers.IO) {
    val connection = (URL("https://world.openfoodfacts.org/api/v2/product/$barcode.json").openConnection() as HttpURLConnection)
    try {
        connection.requestMethod = "GET"
        connection.connectTimeout = 10000
        connection.readTimeout = 10000
        connection.setRequestProperty("User-Agent", "NutriAndroid/1.0 (food barcode lookup)")
        val response = connection.inputStream.bufferedReader().use { it.readText() }
        val root = JSONObject(response)
        if (root.optInt("status") != 1) return@withContext null
        val product = root.optJSONObject("product") ?: return@withContext null
        val nutriments = product.optJSONObject("nutriments") ?: JSONObject()
        val name = product.optString("product_name").ifBlank {
            product.optString("product_name_es").ifBlank { "Producto $barcode" }
        }
        var kcal = nutriments.optDouble("energy-kcal_100g", 0.0)
        if (kcal <= 0.0) {
            val kj = nutriments.optDouble("energy_100g", 0.0)
            if (kj > 0) kcal = kj / 4.184
        }
        val protein = nutriments.optDouble("proteins_100g", 0.0)
        val carbs = nutriments.optDouble("carbohydrates_100g", 0.0)
        val fat = nutriments.optDouble("fat_100g", 0.0)
        if (name.isBlank() || kcal <= 0.0) return@withContext null
        Food(name, kcal.toInt(), protein, carbs, fat, "Open Food Facts · por 100 g")
    } finally {
        connection.disconnect()
    }
}

@Composable
fun BarcodeScannerScreen(modifier: Modifier = Modifier, onFoodFound: (Food) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var barcode by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("Apunta la cámara al código de barras del producto.") }
    var loading by remember { mutableStateOf(false) }
    var permissionGranted by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED)
    }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        permissionGranted = granted
        if (!granted) status = "Necesitas conceder permiso de cámara para escanear. También puedes escribir el código manualmente."
    }

    fun searchCode(code: String) {
        val normalized = code.filter { it.isDigit() }
        if (normalized.length !in 8..14) {
            status = "El código debe contener entre 8 y 14 dígitos."
            return
        }
        barcode = normalized
        loading = true
        status = "Buscando producto en Open Food Facts…"
        scope.launch {
            try {
                val food = lookupOpenFoodFacts(normalized)
                if (food == null) {
                    status = "No encontramos información nutricional suficiente para este código."
                } else {
                    status = "Producto encontrado. Revisa la información antes de añadirlo."
                    onFoodFound(food)
                }
            } catch (_: Exception) {
                status = "No se pudo consultar la base de datos. Comprueba tu conexión e inténtalo de nuevo."
            } finally {
                loading = false
            }
        }
    }

    Column(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Escáner de productos", fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Text("Lee el código de barras y consulta los datos disponibles en Open Food Facts.")
        if (permissionGranted) {
            BarcodeCameraPreview(
                modifier = Modifier.fillMaxWidth().height(300.dp),
                onBarcode = { code -> if (!loading && barcode != code) searchCode(code) }
            )
        } else {
            Card {
                Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Permiso de cámara necesario")
                    Button(onClick = { permissionLauncher.launch(Manifest.permission.CAMERA) }) { Text("Permitir cámara") }
                }
            }
        }
        OutlinedTextField(
            value = barcode,
            onValueChange = { barcode = it.filter(Char::isDigit).take(14) },
            modifier = Modifier.fillMaxWidth(),
            label = { Text("O escribe el código de barras") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            singleLine = true
        )
        Button(onClick = { searchCode(barcode) }, enabled = !loading && barcode.length in 8..14, modifier = Modifier.fillMaxWidth()) {
            if (loading) CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
            else Text("Buscar producto")
        }
        Text(status, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text("Los datos provienen de Open Food Facts y pueden estar incompletos o ser aportados por usuarios. Comprueba siempre la etiqueta del envase.", fontSize = 12.sp)
    }
}

@Composable
fun BarcodeCameraPreview(modifier: Modifier = Modifier, onBarcode: (String) -> Unit) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val currentOnBarcode by rememberUpdatedState(onBarcode)
    var previewView by remember { mutableStateOf<PreviewView?>(null) }

    AndroidView(
        modifier = modifier,
        factory = { ctx ->
            PreviewView(ctx).apply {
                scaleType = PreviewView.ScaleType.FILL_CENTER
                layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
                previewView = this
            }
        }
    )

    DisposableEffect(previewView, lifecycleOwner) {
        val view = previewView
        if (view == null) return@DisposableEffect onDispose { }
        val cameraExecutor = Executors.newSingleThreadExecutor()
        val barcodeScanner = BarcodeScanning.getClient()
        val providerFuture = ProcessCameraProvider.getInstance(context)
        providerFuture.addListener({
            try {
                val cameraProvider = providerFuture.get()
                val preview = Preview.Builder().build().also { it.setSurfaceProvider(view.surfaceProvider) }
                val analysis = ImageAnalysis.Builder()
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .build()
                val alreadyRead = AtomicBoolean(false)
                analysis.setAnalyzer(cameraExecutor) { imageProxy ->
                    val mediaImage = imageProxy.image
                    if (mediaImage == null) {
                        imageProxy.close()
                    } else {
                        val image = InputImage.fromMediaImage(mediaImage, imageProxy.imageInfo.rotationDegrees)
                        barcodeScanner.process(image)
                            .addOnSuccessListener { results ->
                                val value = results.firstOrNull()?.rawValue
                                if (!value.isNullOrBlank() && alreadyRead.compareAndSet(false, true)) {
                                    currentOnBarcode(value)
                                }
                            }
                            .addOnCompleteListener { imageProxy.close() }
                    }
                }
                cameraProvider.unbindAll()
                cameraProvider.bindToLifecycle(lifecycleOwner, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis)
            } catch (_: Exception) {
                // La pantalla permite introducir el código manualmente si la cámara no está disponible.
            }
        }, ContextCompat.getMainExecutor(context))

        onDispose {
            runCatching { providerFuture.get().unbindAll() }
            barcodeScanner.close()
            cameraExecutor.shutdown()
        }
    }
}

@Composable
fun FoodAmountDialog(food: Food, onDismiss: () -> Unit, onAdd: (Int) -> Unit) {
    var grams by remember { mutableStateOf("100") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Añadir ${food.name}") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Información nutricional por 100 g: ${food.calories} kcal.")
                OutlinedTextField(grams, { grams = it }, label = { Text("Cantidad en gramos") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                val amount = grams.toIntOrNull()
                if (amount != null && amount in 1..2000) {
                    val ratio = amount / 100.0
                    Text("Total estimado: ${(food.calories * ratio).toInt()} kcal · P ${(food.protein * ratio).toInt()} g · C ${(food.carbs * ratio).toInt()} g · G ${(food.fat * ratio).toInt()} g")
                }
            }
        },
        confirmButton = { TextButton(onClick = { grams.toIntOrNull()?.takeIf { it in 1..2000 }?.let(onAdd) }) { Text("Añadir") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

@Composable
fun ProgressScreen(calories: Int, weights: List<WeightEntry>, modifier: Modifier = Modifier) {
    LazyColumn(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("Tu progreso", fontSize = 25.sp, fontWeight = FontWeight.Bold) }
        item { Card { Column(Modifier.fillMaxWidth().padding(18.dp)) { Text("Calorías registradas hoy"); Text("$calories kcal", fontSize = 30.sp, fontWeight = FontWeight.Bold) } } }
        item { Text("Historial de peso", fontSize = 19.sp, fontWeight = FontWeight.Bold) }
        if (weights.isEmpty()) item { Text("Añade tu primer registro de peso con el botón +.") }
        items(weights, key = { it.id }) { entry -> Card { Row(Modifier.fillMaxWidth().padding(14.dp), horizontalArrangement = Arrangement.SpaceBetween) { Text(dateLabel(entry.timestamp)); Text("${"%.1f".format(Locale.getDefault(), entry.kg)} kg", fontWeight = FontWeight.Bold) } } }
        item { Text("Observa las tendencias a lo largo del tiempo, no solo un dato aislado.", fontSize = 12.sp) }
    }
}

@Composable
fun ProfileScreen(profile: UserProfile, onSave: (UserProfile) -> Unit, modifier: Modifier = Modifier) {
    var name by remember(profile) { mutableStateOf(profile.name) }
    var age by remember(profile) { mutableStateOf(profile.age.toString()) }
    var height by remember(profile) { mutableStateOf(profile.heightCm.toString()) }
    var weight by remember(profile) { mutableStateOf(profile.weightKg.toString()) }
    var sex by remember(profile) { mutableStateOf(profile.sex) }
    var activity by remember(profile) { mutableStateOf(profile.activity) }
    var goal by remember(profile) { mutableStateOf(profile.goal) }
    var activityExpanded by remember { mutableStateOf(false) }
    var goalExpanded by remember { mutableStateOf(false) }
    val candidate = UserProfile(name, age.toIntOrNull() ?: 30, height.replace(',', '.').toDoubleOrNull() ?: 170.0, weight.replace(',', '.').toDoubleOrNull() ?: 70.0, sex, activity, goal)
    val valid = name.length <= 60 && (age.toIntOrNull() ?: 0) in 13..100 && (height.replace(',', '.').toDoubleOrNull() ?: 0.0) in 100.0..230.0 && (weight.replace(',', '.').toDoubleOrNull() ?: 0.0) in 30.0..300.0

    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Mi perfil", fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Text("Completa estos datos para obtener una estimación orientativa.")
        OutlinedTextField(name, { name = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Nombre (opcional)") }, singleLine = true)
        OutlinedTextField(age, { age = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Edad (13 a 100 años)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
        OutlinedTextField(height, { height = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Estatura en cm") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
        OutlinedTextField(weight, { weight = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Peso actual en kg") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
        Text("Sexo usado por la fórmula de estimación")
        Row(verticalAlignment = Alignment.CenterVertically) {
            RadioButton(selected = sex == "Mujer", onClick = { sex = "Mujer" }); Text("Mujer")
            Spacer(Modifier.width(16.dp))
            RadioButton(selected = sex == "Hombre", onClick = { sex = "Hombre" }); Text("Hombre")
        }
        Box {
            OutlinedButton(onClick = { activityExpanded = true }, modifier = Modifier.fillMaxWidth()) { Text("Actividad: $activity") }
            DropdownMenu(expanded = activityExpanded, onDismissRequest = { activityExpanded = false }) {
                listOf("Sedentaria", "Ligera", "Moderada", "Alta", "Muy alta").forEach { option ->
                    DropdownMenuItem(text = { Text(option) }, onClick = { activity = option; activityExpanded = false })
                }
            }
        }
        Box {
            OutlinedButton(onClick = { goalExpanded = true }, modifier = Modifier.fillMaxWidth()) { Text("Objetivo: $goal") }
            DropdownMenu(expanded = goalExpanded, onDismissRequest = { goalExpanded = false }) {
                listOf("Perder peso", "Mantener", "Ganar peso").forEach { option ->
                    DropdownMenuItem(text = { Text(option) }, onClick = { goal = option; goalExpanded = false })
                }
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
            Column(Modifier.fillMaxWidth().padding(14.dp)) {
                Text("Estimación diaria", fontWeight = FontWeight.SemiBold)
                Text("${estimatedCalories(candidate)} kcal", fontSize = 27.sp, fontWeight = FontWeight.Bold)
                Text("Estimación general basada en edad, estatura, peso, sexo, actividad y objetivo.", fontSize = 12.sp)
            }
        }
        Button(onClick = { onSave(candidate) }, enabled = valid, modifier = Modifier.fillMaxWidth()) { Text("Guardar perfil y actualizar objetivo") }
        Text("La fórmula es orientativa. No se aplica a menores de 13 años, embarazo, lactancia ni situaciones clínicas; consulta con un profesional para una meta adecuada.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun AddMealDialog(onDismiss: () -> Unit, onAdd: (Meal) -> Unit) {
    var name by remember { mutableStateOf("") }; var kcal by remember { mutableStateOf("") }; var protein by remember { mutableStateOf("") }; var carbs by remember { mutableStateOf("") }; var fat by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Añadir comida manual") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
            OutlinedTextField(name, { name = it }, label = { Text("Nombre del alimento o comida") }, singleLine = true)
            NumberField(kcal, { kcal = it }, "Calorías (kcal)")
            NumberField(protein, { protein = it }, "Proteína (g)")
            NumberField(carbs, { carbs = it }, "Carbohidratos (g)")
            NumberField(fat, { fat = it }, "Grasas (g)")
        }
    }, confirmButton = { TextButton(onClick = { val c = kcal.toIntOrNull(); if (name.isNotBlank() && c != null && c >= 0) onAdd(Meal(name = name.trim(), calories = c, protein = protein.toIntOrNull()?.coerceAtLeast(0) ?: 0, carbs = carbs.toIntOrNull()?.coerceAtLeast(0) ?: 0, fat = fat.toIntOrNull()?.coerceAtLeast(0) ?: 0)) }) { Text("Guardar") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } })
}

@Composable
fun NumberField(value: String, onValue: (String) -> Unit, label: String) {
    OutlinedTextField(value, onValue, label = { Text(label) }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
}

@Composable
fun AddWeightDialog(onDismiss: () -> Unit, onAdd: (WeightEntry) -> Unit) {
    var value by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Registrar peso") }, text = { OutlinedTextField(value, { value = it }, label = { Text("Peso en kg") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true) }, confirmButton = { TextButton(onClick = { val kg = value.replace(',', '.').toDoubleOrNull(); if (kg != null && kg in 1.0..500.0) onAdd(WeightEntry(kg = kg)) }) { Text("Guardar") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } })
}
