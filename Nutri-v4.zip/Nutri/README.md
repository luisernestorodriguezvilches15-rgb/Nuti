# Nutri v4 — Android

## Novedades de esta versión
- Escáner de códigos de barras con CameraX y Google ML Kit.
- Consulta de producto por código de barras a Open Food Facts.
- Búsqueda manual de código como alternativa a la cámara.
- Datos nutricionales por 100 g convertidos a una cantidad elegida en gramos desde el flujo de catálogo.
- Permiso de cámara e internet declarados en AndroidManifest.
- Punto de integración seguro para futura función Supabase `analyze-meal` (todavía no realiza inferencia IA).

## Abrir el proyecto
1. Descomprime `Nutri-v4.zip`.
2. Abre la carpeta `Nutri` en Android Studio.
3. Usa JDK 17 y Android SDK 35.
4. Acepta la sincronización de Gradle.
5. Ejecuta en un dispositivo Android con cámara y conexión a internet.

## Escáner
La app usa CameraX + ML Kit para leer el código y consulta:
`https://world.openfoodfacts.org/api/v2/product/{barcode}.json`

Open Food Facts es una base colaborativa. Los productos pueden no existir, tener campos incompletos o contener datos incorrectos. Revisa la etiqueta del envase. El catálogo está sujeto a la disponibilidad del servicio y a sus términos de uso.

## Estado real
- El código del escáner está incorporado, pero requiere compilación y prueba en un teléfono Android real.
- No se ha ejecutado una compilación Gradle en este entorno.
- No hay todavía captura de fotografías de comidas ni análisis IA activo.
- `supabase/functions/analyze-meal` es solo un endpoint de preparación que devuelve `501 not_configured`.
- No hay sincronización Supabase configurada.

## Seguridad
No coloques claves privadas de IA ni `service_role` de Supabase en la app Android. Las credenciales de proveedores deben residir en secretos de funciones Edge.
