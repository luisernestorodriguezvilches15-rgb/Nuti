-- Esquema inicial de Nutri. Ejecutar en el SQL Editor de tu proyecto Supabase.
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  created_at timestamptz not null default now()
);

create table if not exists public.meals (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  name text not null,
  calories integer not null default 0 check (calories >= 0),
  protein_g numeric(8,2) not null default 0 check (protein_g >= 0),
  carbs_g numeric(8,2) not null default 0 check (carbs_g >= 0),
  fat_g numeric(8,2) not null default 0 check (fat_g >= 0),
  eaten_at timestamptz not null default now(),
  created_at timestamptz not null default now()
);

create table if not exists public.weight_entries (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  weight_kg numeric(6,2) not null check (weight_kg > 0 and weight_kg < 501),
  recorded_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.meals enable row level security;
alter table public.weight_entries enable row level security;

create policy "Users manage own profile" on public.profiles
for all using (auth.uid() = id) with check (auth.uid() = id);
create policy "Users manage own meals" on public.meals
for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "Users manage own weight" on public.weight_entries
for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
