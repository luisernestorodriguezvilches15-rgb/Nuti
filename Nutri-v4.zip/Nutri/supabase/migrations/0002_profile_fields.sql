-- Perfil nutricional ampliado. Ejecutar después de 0001_schema.sql.
alter table public.profiles
  add column if not exists age integer check (age between 13 and 100),
  add column if not exists height_cm numeric(5,2) check (height_cm between 100 and 230),
  add column if not exists weight_kg numeric(6,2) check (weight_kg between 30 and 300),
  add column if not exists sex text check (sex in ('Mujer', 'Hombre')),
  add column if not exists activity_level text,
  add column if not exists goal text;
