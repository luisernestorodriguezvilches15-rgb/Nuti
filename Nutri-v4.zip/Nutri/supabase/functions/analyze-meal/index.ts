// Nutri: endpoint seguro de análisis de comidas.
// Esta función es un punto de integración, no contiene un proveedor de IA configurado.
Deno.serve(async (req: Request) => {
  if (req.method !== "POST") {
    return new Response(JSON.stringify({ error: "Method not allowed" }), {
      status: 405,
      headers: { "content-type": "application/json" },
    });
  }

  const authorization = req.headers.get("Authorization");
  if (!authorization) {
    return new Response(JSON.stringify({ error: "Authentication required" }), {
      status: 401,
      headers: { "content-type": "application/json" },
    });
  }

  // Próximo paso: validar JWT con Supabase Auth, validar tamaño/tipo de imagen,
  // llamar al proveedor de IA usando un secreto del servidor y devolver
  // alimentos + estimaciones con nivel de confianza. Nunca aceptar claves
  // privadas enviadas desde la aplicación móvil.
  return new Response(JSON.stringify({
    status: "not_configured",
    message: "El análisis con IA todavía no está configurado.",
  }), {
    status: 501,
    headers: { "content-type": "application/json" },
  });
});
